import React from 'react';
import Subheading from './../../components/Subheading/Subheading';
import burger from './../../assets/images/burger2.jpg';
import './Header.css';

function Header() {
  return (
    <div className='app_header app_wrapper section_padding'>
      <div className='app_wrapper_info'>
        <Subheading title="Chase The New Flavour" />
        <h1 className='app_header-h1'>The Key To Fine Dining</h1>
        <p></p>
        <button className='btn btn-info'>Explore Menu</button>
      </div>

      <div className='app_wrapper_img'>
        <img src={burger} alt="burger"></img>
      </div>
    </div>
  )
}

export default Header