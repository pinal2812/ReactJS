import React from 'react';
import spoon from './../../assets/images/spoon.png'

function Subheading(props) {
  return (
    <div>
      <p className='p_cormorant' style={{color: '#fff'}}>{props.title}</p>
      <img src={spoon} alt="logo2" className='logo_img' width={70}></img>
    </div>
  )
}

export default Subheading