import React, { useState } from 'react';
import { GiHamburgerMenu } from 'react-icons/gi';
import { MdOutlineRestaurantMenu } from 'react-icons/md';
import logo from './../../assets/images/logo.jpg';
import './Navbar.css'

function Navbar() {
    const [toggleMenu, setToggleMenu] = useState(false);

    return (
        <nav className='app_navbar'>
            <div className='app_navbar-logo'>
                <img src={logo} alt='app logo' width={50}></img>
            </div>
            <ul className='app_navbar-links'>
                <li className='app_navbar-list'><a href='#home'>Home</a></li>
                <li className='app_navbar-list'><a href='#about'>About</a></li>
                <li className='app_navbar-list'><a href='#menu'>Menu</a></li>
                <li className='app_navbar-list'><a href='#awards'>Awards</a></li>
                <li className='app_navbar-list'><a href='#contact'>Contact</a></li>
            </ul>
            <div className='app_navbar-login'>
                <a href='#login' className='app_navbar-list'>Log In / Register</a>
                <div />
                <a href='/' className='app_navbar-list'>Book Table</a>
            </div>
            <div className='app_navbar-smallscreen'>
                <GiHamburgerMenu color='#fff' fontSize={27} onClick={() => setToggleMenu(true)} />

                {toggleMenu && (
                    <div className='app_navbar-smallscreen_overlay flex_center slide-bottom'>
                        <MdOutlineRestaurantMenu className='overlay_close' fontSize={27} onClick={() => setToggleMenu(false)} />
                        <ul className='app_navbar-smallscreen-links'>
                            <li className='app_navbar-list'><a href='#home'>Home</a></li>
                            <li className='app_navbar-list'><a href='#about'>About</a></li>
                            <li className='app_navbar-list'><a href='#menu'>Menu</a></li>
                            <li className='app_navbar-list'><a href='#awards'>Awards</a></li>
                            <li className='app_navbar-list'><a href='#contact'>Contact</a></li>
                        </ul>
                    </div>
                )}

            </div>
        </nav>
    )
}

export default Navbar