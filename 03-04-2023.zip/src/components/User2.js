import React from 'react'
import User3 from './User3'

function User2() {
  return (
    <div>
        <User3 />
    </div>
  )
}

export default User2