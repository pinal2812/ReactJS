import { React, useState } from "react";

export default function Mapping() {
  // const array=["HTML","CSS","JS","BOOTSTRAP","JQUERY","REACT","Adv JS"]
  // const newArray = array.map((val)=>{
  //     return <tr>{val}</tr>;
  // });

  const [count, setCount] = useState(0)

  const Increment = () => {
      setCount(count + 1);
  }
  const Decrement = () => {
      setCount(count - 1);
  }

  return <>
  {
    count%2 === 0 ? (
      <h1 style={{color : "green"}}>{count}</h1>
    ) : 
    (
      <h1 style={{color: "red"}}>{count}</h1>
    )
  }
    <button onClick={Increment}>+</button>
    <button onClick={Decrement}>-</button>
  </>

  // return <>
  //     <table border={1}>
  //         <td>{newArray}</td>
  //     </table>
  // </>
}