import React from 'react';
import { Mydata } from './App';

function User3() {
  return (
    <div>
      <Mydata.Consumer>{(data)=>{
        return <h1>{data}</h1>
      }}
      </Mydata.Consumer>
    </div>
  )
}

export default User3