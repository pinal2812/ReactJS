import React from "react";

export default function Slider(props) {
    return <div id="carouselExample" className="carousel slide container" style={{backgroundColor:"GrayText"}}>
        <div className="carousel-inner" style={{textAlign:"center"}}>
            <div className="carousel-item active" >
                <video className="rounded" src={props.item1} autoPlay="true" controls></video>
                <h1 className='txt'>The Pink Flowers</h1>
            </div>
            <div className="carousel-item">
                <video className="rounded" src={props.item2} autoPlay="true" controls></video>
                <h1 className='txt'>The Sea</h1>
            </div>
            <div className="carousel-item">
                <video className="rounded" src={props.item3} autoPlay="true" controls></video>
                <h1 className='txt'>The Petals</h1>
            </div>
            <div className="carousel-item">
                <video className="rounded" src={props.item4} autoPlay="true" controls></video>
                <h1 className='txt'>The Fire Balloon</h1>
            </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
        </button>
    </div>
}