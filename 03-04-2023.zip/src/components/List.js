import React, { useState, useEffect} from 'react'

function List() {
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('https://fakestoreapi.com/products')
            // fetch('https://api.openweathermap.org/data/2.5/weather?q=surat&appid=33bb341d89f3c041815c9bb48b98c1d1')
            .then((res) => {
                return res.json()
            })
            .then((data) => {
                setData(data)
            })
    }, [])

    const listItems = data.map(product =>
        <li class="list-group-item">{product.title}</li>
    );

    return (
        <ul class="list-group">{listItems}</ul>
      );
}

export default List