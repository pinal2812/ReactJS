import React, { createContext, useEffect, useState } from 'react'
import User1 from './User1';
const Mydata = createContext()

function App() {
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('https://fakestoreapi.com/products')
        // fetch('https://api.openweathermap.org/data/2.5/weather?q=surat&appid=33bb341d89f3c041815c9bb48b98c1d1')
            .then((res) => {
                return res.json()
            })
            .then((data) => {
                setData(data)
            })
    }, [])
    return (
        <div className='container text-center'>
            <div className='row justify-content-start'>
                {data.map((item) => {
                    return (
                        <div className='col'>
                            <div className="card" style={{ width: "18rem" }}>
                                <img src={item.image} className="card-img-top" alt="..." style={{ height: "75px", width: "75px" }} />
                                <div className="card-body">
                                    <h5 className="card-title">{item.title}</h5>
                                    <h3 className="card-title">{item.price}</h3>
                                    <p className="card-text">{item.description.substr(0,24)}</p>
                                    <a href="index.html" className="btn btn-primary">Details</a>
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )

    return(
        <Mydata.Provider value={"React Js"}>
            <User1/>
        </Mydata.Provider>
    )
}

export default App;
export {Mydata}