import React from "react";
import './css/Header.css'

export default function Footer() {
    return <>
        <div className="alert alert-primary txt-header" role="alert">
            Thank You For Visting !!!
        </div>
    </>
}