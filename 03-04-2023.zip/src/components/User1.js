import React from 'react';
import User2 from './User2';

function User1() {
    return (
        <>
            <div>
                <User2 />
            </div>
        </>
    )
}

export default User1