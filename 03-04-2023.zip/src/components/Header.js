import React from "react";
import './css/Header.css'

export default function Header() {
    return <>
        <div className="alert alert-primary txt-header" role="alert">
            React Tutorial
        </div>
    </>
}