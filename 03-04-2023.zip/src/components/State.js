import React, { useState } from 'react'

function State() {
    const [text,setColor] = useState("Black")
    const [textColor,setTextColor] = useState("Black")

    const red = () => {
        setColor('Red')
        setTextColor('Red')
    }
    const green = () => {
        setColor('Green')
        setTextColor('Green')
    }
    const yellow = () => {
        setColor('Yellow')
        setTextColor('Yellow')
    }
    const pink = () => {
        setColor('Pink')
        setTextColor('Pink')
    }
    const Orange = () => {
        setColor('Orange')
        setTextColor('Orange')
    }
  return (
    <>
    <h2 style={{ color: textColor }}>You have to clicked on {text}</h2>
    <button onClick={red}>Red</button>
    <button onClick={green}>Green</button>
    <button onClick={yellow}>Yellow</button>
    <button onClick={pink}>Pink</button>
    <button onClick={Orange}>Orange</button>
    </>
  )
}

export default State