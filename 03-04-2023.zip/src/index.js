import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Header from './components/Header';
// import Footer from './components/Footer';
// import Slider from './components/Slider';
// import Mapping from './components/Mapping';
// import State from './components/State';
import App from './components/App';
import List from './components/List';

// var flowers = require('./components/images/flowers.mp4')
// var sea = require('./components/images/sea.mp4')
// var petals = require('./components/images/petals.mp4')
// var balloon = require('./components/images/balloon.mp4')

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Header/>
    <List/>
    <App />
    {/* <Mapping/>
    <State />
    <Slider item1={flowers} item2={sea} item3={petals} item4={balloon}/>
    <Footer/> */}
  </React.StrictMode>
);