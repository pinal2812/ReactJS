import React, { useState, createContext } from 'react';
import { Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home/Home';
import Menu from './pages/Menu/Menu';
import Delivery from './pages/Delivery/Delivery';
import About from './pages/About/About';
import Contact from './pages/Contact/Contact';
import Galary from './pages/Galary/Galary';
import GalaryDetails from './pages/Galary/GalaryDetails';
import Login from './components/Login/Login';
import PrivateRoute from './components/PrivateRoute';
// import Footer from './components/Footer/Footer';

export const WrapperContext = createContext();

function App() {

  const [login, setLogin] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [city, setCity] = useState("");
  const [tableData, setTableData] = useState([]);

  const [isEdit, setIsEdit] = useState(false);
  const [editId, setEditId] = useState(null);

  function deleteData(id) {
    const deleteItem = tableData.filter((item) => item.id !== id)
    setTableData(deleteItem)
  }

  function addToEditStage(item) {
    const { id, firstName, lastName, city } = item
    setIsEdit(true)
    setEditId(id)

    setFirstName(firstName)
    setLastName(lastName)
    setCity(city)
  }

  function handleEdit(e) {
    e.preventDefault();
    const editItems = tableData.map((item) => {
      if(item.id === editId) {
        return {...item, firstName, lastName, city}
      } else {
        return item
      }
    })

    setFirstName('')
    setLastName('')
    setCity('')
    setIsEdit(false)
    setEditId(null)
    setTableData(editItems)
  }

  return (
    <>
      <WrapperContext.Provider value={{ login, setLogin, firstName, setFirstName, lastName, setLastName, city, setCity, tableData, setTableData, deleteData, addToEditStage, isEdit, handleEdit }}>
        <Navbar />
        <Routes>
          <Route path='/' element={<Home />}></Route>
          <Route path='/menu' element={<Menu />}></Route>
          <Route path='/delivery' element={<Delivery />}></Route>
          <Route path='/about' element={<About />}></Route>
          <Route path='/contact' element={<Contact />}></Route>
          <Route path='/galary' element={<PrivateRoute><Galary /></PrivateRoute>}></Route>
          <Route path='/galary/:id' element={<PrivateRoute><GalaryDetails /></PrivateRoute>}></Route>
          <Route path='/login' element={<Login />}></Route>
        </Routes>
        {/* <Footer/> */}
      </WrapperContext.Provider>
    </>
  );
}

export default App;
