import React from 'react'

export default function Menu() {
  return (
    <div>
      Menu
    </div>
  )
}
