import React from 'react'

export default function Delivery() {
  return (
    <div>
        Delivery
    </div>
  )
}
