import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Galary() {
    const [cocktailList, setCocktailList] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState("");

    const navigate = useNavigate();

    useEffect(() => {
        fetch(`https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${search}`)
            .then((resp) => resp.json())
            .then((data) => {
                setCocktailList(data.drinks)
                setLoading(false)
            })
    }, [search]);

    if (loading) {
        return (
            <div className='container'>
                <div className='section'>
                    <div className='d-flex justify-content-center'>
                        <div className="spinner-border" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    return (
        <div className="container py-5">
            <div className='section'>
                <input
                    value={search}
                    className='form-control mb-2'
                    placeholder='search cocktails...'
                    onChange={(e) => setSearch(e.target.value)} />
                <div className="row">
                    {cocktailList && cocktailList.map((item) => {
                        const {
                            idDrink,
                            strDrink,
                            strCategory,
                            strInstructions,
                            strDrinkThumb
                        } = item;

                        return (
                            <div className="col-md-4 mb-3" key={idDrink}>
                                <div className="card">
                                    <img src={strDrinkThumb} alt="" />
                                    <div className="card-body">
                                        <h5>{strDrink}</h5>
                                        <span className="text-secondary">{strCategory}</span>
                                        <p className="text-truncate">{strInstructions}</p>
                                        {/* <Link
                                            to={`/galary/${idDrink}`}
                                            className="btn btn-secondary"
                                        >
                                            More Details
                                        </Link> */}

                                        <button
                                            onClick={() =>
                                                navigate(`/galary/${idDrink}`, { state: item })
                                            }
                                            className="btn btn-secondary"
                                        >
                                            More Details
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}

export default Galary