import React, { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { IoArrowBackSharp } from 'react-icons/io5';
import { FaSpinner } from 'react-icons/fa';

function GalaryDetails() {
  const params = useParams();

  const [details, setDetails] = useState({});
  const [loading, setLoading] = useState(true);

  const {state} = useLocation();

  // const navigate = useNavigate();

  useEffect(() => {
    setDetails(state)
  },[state])

  useEffect(() => {
    fetch(`https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${params.id}`)
      .then((resp) => resp.json())
      .then((data) => {
        setDetails(data.drinks[0]);
        setLoading(false)
      })
      .catch((err) => console.log(err))
  }, []);

  if (loading) {
    return (
      <div className='container'>
        <div className='section'>
          <div className='d-flex justify-content-center py-5'>
            <FaSpinner />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className='container py-5 m-5'>
      <div className='section'>
        {/* <button className='btn btn-secondary' onClick={() => navigate('/')}>back</button> */}

        <Link className='btn btn-secondary' to="/galary"><IoArrowBackSharp /></Link>

        <div className='row py-5'>
          <div className='col-md-4'>
            <img src={details.strDrinkThumb} width="100%"></img>
          </div>
          <div className='col-md-8'>
            <h2>name : {details.strDrink}</h2>
            <span>category : {details.strCategory}</span>
            <p>details : {details.strInstructions}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default GalaryDetails