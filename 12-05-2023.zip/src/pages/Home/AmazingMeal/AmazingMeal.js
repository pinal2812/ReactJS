import React, { useState } from 'react';
import './AmazingMeal.css';

import img1 from './../../../assets/images/food1.jpg'
import img2 from './../../../assets/images/pasta.jpg'
import img3 from './../../../assets/images/pizza2.jpg'
import img4 from './../../../assets/images/sandwich2.jpg'
import img5 from './../../../assets/images/burger items.jpg'

import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export default function AmazingMeal() {
    const [items, setItems] = useState([
        {id:1, URL:img1},
        {id:2, URL:img2},
        {id:3, URL:img3},
        {id:4, URL:img4},
        {id:5, URL:img5},
    ]);

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
    };
    return (
        <div className='section'>
            <div className='container'>
                <div className='amazing-container'>
                    <div className='amazing-carousal'>
                        <div>
                            <Slider {...settings}>
                                {items.map((item) => (
                                    <div key={item.id}>
                                        <img src={item.URL} alt='carousel'></img>
                                    </div>
                                ))}
                            </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
