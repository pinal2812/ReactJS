import React from 'react';
import './Main.css'

export default function Main() {
  return (
    <div className='main-img container'>
        <div className='main-content'>
            <h1 className='heading-primary'>
                <span>Welcome</span> to restaurant
            </h1>
        </div>
    </div>
  )
}