import React from 'react';
import Main from './Main/Main';
import AmazingMeal from './AmazingMeal/AmazingMeal';

export default function Home() {
  return (
    <div>
      <Main />
      <AmazingMeal />
    </div>
  )
}