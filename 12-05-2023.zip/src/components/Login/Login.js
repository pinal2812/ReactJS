import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import { WrapperContext } from '../../App';

function Login() {

    const { setLogin } = useContext(WrapperContext);
    const navigate = useNavigate();

    const { firstName, setFirstName, lastName, setLastName, city, setCity, tableData, setTableData, deleteData, addToEditStage, isEdit, handleEdit } = useContext(WrapperContext);

    function login(e) {
        e.preventDefault();
        // setLogin(true);
        // navigate('/');

        const date = new Date();

        const formValue = { id: date.getTime(), firstName, lastName, city };
        setTableData([...tableData, formValue]);

        setFirstName('')
        setLastName('')
        setCity('')
    }

    return (
        <div className='container py-5'>
            <div className='section'>
                <div className='row'>
                    <div className='col-md-6' offset-md-3 p-3 shadow my-5>
                        <h3 className='text-center'>Login</h3>
                        <form action=''>
                            <div className='mb-3'>
                                <input type='text' placeholder='Enter First Name' className='form-control' value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                            </div>
                            <div className='mb-3'>
                                <input type='text' placeholder='Enter Last Name' className='form-control' value={lastName} onChange={(e) => setLastName(e.target.value)} />
                            </div>
                            <div className='mb-3'>
                                <input type='text' placeholder='Enter City' className='form-control' value={city} onChange={(e) => setCity(e.target.value)} />
                            </div>
                            {isEdit ? (
                                <button class="btn btn-primary" onClick={handleEdit}>Edit Data</button>
                            ) : (
                                <button class="btn btn-primary" onClick={login}>Add Data</button>
                            )}
                        </form>
                    </div>
                </div>
            </div>

            <div className='section'>
                <table className='table table-primary'>
                    <thead>
                        <tr>
                            <th>Sr No</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>City</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tableData.map((item, index) => {
                            const { firstName, lastName, city, id } = item;

                            return (
                                <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td>{firstName}</td>
                                    <td>{lastName}</td>
                                    <td>{city}</td>
                                    <td>
                                        <button className='btn btn-danger' onClick={() => deleteData(id)}>Delete</button>
                                        <button className='btn btn-warning' onClick={() => addToEditStage(item)}>Edit</button>
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default Login