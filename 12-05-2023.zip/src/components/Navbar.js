import React, { useState } from 'react';

import { Link, NavLink } from 'react-router-dom';
import logo from './../assets/images/logo.jpg';
import './Navbar.css';
import { FaBars, FaTimes } from 'react-icons/fa';

export default function Navbar() {
  const [toggleMenu, setToggleMenu] = useState(false);

  const handleClick = () => {
    setToggleMenu(!toggleMenu)
  }

  return (
    <div className='header'>
      <div className='container'>
        <div className='nav-bar'>
          <Link to="/">
          <img src={logo} alt="logo" width={50} />
          </Link>

          <ul className={toggleMenu ? "nav-menu active" : "nav-menu"}>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/">Home</NavLink>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/menu">Menu</NavLink>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/delivery">Delivery</NavLink>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/about">About</NavLink>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/contact">Contact</NavLink>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/galary">Galary</NavLink>
            </li>
            <li onClick={handleClick}>
              <button>Order Now</button>
            </li>
            <li onClick={handleClick}>
              <NavLink className="nav-link" to="/login">Login</NavLink>
            </li>
          </ul>

          <div className='hamburger' onClick={handleClick}>
            { toggleMenu ? (
              <FaTimes size={20} style={{color:"#0000"}} />
            ) : (
              <FaBars size={20} style={{color:"#fff"}} />
            )
            }
          </div>
        </div>
      </div>
    </div>
  )
}