import React, { useContext } from 'react'
import { WrapperContext } from '../App';
import { Navigate } from 'react-router-dom';

function PrivateRoute({ children }) {

    const { login } = useContext(WrapperContext);

    if( login ){
        return children;
    }
    return (
        <Navigate to='/login'></Navigate>
    )
}

export default PrivateRoute