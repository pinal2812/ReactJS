import React from 'react';
import './Footer.css'

export default function Footer() {
  return (
    <div className='section footer'>
      <div className='container'>
        <div className='grid-container'>
          <div className='footer-grid-item'>
            <h3>Thanks For Visiting</h3>
          </div>
        </div>
      </div>
    </div>
  )
}